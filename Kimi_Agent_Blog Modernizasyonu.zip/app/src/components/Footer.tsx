import { Twitter, Facebook, Instagram, Youtube } from 'lucide-react';

const footerLinks = [
  { label: 'Anasayfa', href: '#hero' },
  { label: 'Blog', href: '#blog' },
  { label: 'Galeri', href: '#gallery' },
  { label: 'Hakkımda', href: '#about' },
  { label: 'Videolar', href: '#videos' },
  { label: 'İletişim', href: '#contact' },
];

const socialLinks = [
  { icon: Twitter, href: 'https://twitter.com/', label: 'Twitter' },
  { icon: Facebook, href: 'https://www.facebook.com/', label: 'Facebook' },
  { icon: Instagram, href: 'https://www.instagram.com/', label: 'Instagram' },
  { icon: Youtube, href: 'https://www.youtube.com/', label: 'YouTube' },
];

export default function Footer() {
  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    if (href.startsWith('#')) {
      e.preventDefault();
      document.querySelector(href)?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-siamese-surface py-12 md:py-16">
      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-8 mb-10">
          {/* Brand */}
          <div>
            <h3 className="font-display text-xl text-siamese-text-primary mb-2">Gece'm</h3>
            <p className="text-sm text-siamese-text-secondary/50">Siyam Kedisi Blogu</p>
          </div>

          {/* Links */}
          <div>
            <nav className="flex flex-wrap gap-x-6 gap-y-2">
              {footerLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="text-sm text-siamese-text-secondary hover:text-siamese-blue transition-colors"
                >
                  {link.label}
                </a>
              ))}
            </nav>
          </div>

          {/* Social */}
          <div className="flex md:justify-end gap-4">
            {socialLinks.map((social) => (
              <a
                key={social.label}
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 text-siamese-text-secondary/50 hover:text-siamese-blue transition-colors"
                aria-label={social.label}
              >
                <social.icon size={20} />
              </a>
            ))}
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-white/5 pt-8 text-center md:text-left">
          <p className="text-xs text-siamese-text-secondary/40 mb-1">
            © 2024 Gece'm. Tüm hakları saklıdır.
          </p>
          <p className="text-xs text-siamese-text-secondary/40">
            Bu bloğun hazırlanmasında{' '}
            <a
              href="http://www.siyamkedi.com/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-siamese-blue/60 hover:text-siamese-blue transition-colors"
            >
              www.siyamkedi.com
            </a>{' '}
            sitesinden faydalanılmıştır.
          </p>
        </div>
      </div>
    </footer>
  );
}
