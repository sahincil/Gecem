import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navbar from './components/Navbar';
import Hero from './sections/Hero';
import BlogPosts from './sections/BlogPosts';
import Gallery from './sections/Gallery';
import About from './sections/About';
import Videos from './sections/Videos';
import Contact from './sections/Contact';
import Footer from './components/Footer';
import FloatingParticles from './components/FloatingParticles';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize scroll-triggered animations for all sections
    const sections = document.querySelectorAll('.reveal-section');
    sections.forEach((section) => {
      gsap.from(section, {
        y: 60,
        opacity: 0,
        duration: 1,
        ease: "power3.out",
        scrollTrigger: {
          trigger: section,
          start: "top 85%",
          toggleActions: "play none none reverse",
        },
      });
    });

    return () => {
      ScrollTrigger.getAll().forEach((t) => t.kill());
    };
  }, []);

  return (
    <div ref={mainRef} className="relative min-h-screen bg-siamese-bg">
      <FloatingParticles />
      <Navbar />
      <main>
        <Hero />
        <BlogPosts />
        <Gallery />
        <About />
        <Videos />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
