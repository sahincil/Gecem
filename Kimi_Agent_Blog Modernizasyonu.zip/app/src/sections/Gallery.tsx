import { useState, useEffect, useRef, useCallback } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const galleryImages = [
  { src: '/gallery-1.jpg', alt: 'Gece rahat bir battaniyede uyuyor', caption: 'Rahat bir uyku' },
  { src: '/gallery-2.jpg', alt: 'Gece esniyor', caption: 'Esneme zamanı' },
  { src: '/gallery-3.jpg', alt: 'Gece pencereden dışarı bakıyor', caption: 'Pencere başında' },
  { src: '/gallery-4.jpg', alt: 'Gece sırtüstü yatıyor', caption: 'Göbek gösterisi' },
  { src: '/gallery-5.jpg', alt: 'Gece kadife minderde oturuyor', caption: 'Kraliçe pozu' },
  { src: '/gallery-6.jpg', alt: 'Gece battaniyenin altından bakıyor', caption: 'Battaniye altından' },
  { src: '/gallery-7.jpg', alt: 'Gece bahçede yürüyor', caption: 'Bahçe turu' },
  { src: '/gallery-8.jpg', alt: 'Gece yuvarlak bir pozisyonda uyuyor', caption: 'Mükemmel daire' },
  { src: '/gallery-9.jpg', alt: 'Gece patileri ve bıyıkları', caption: 'Pati detayı' },
  { src: '/about-cat.jpg', alt: 'Gece portre', caption: 'Portre' },
  { src: '/gallery-3.jpg', alt: 'Gece pencerede', caption: 'Yağmurlu bir gün' },
  { src: '/hero-cat.jpg', alt: 'Gece hero görseli', caption: 'Ana sahne' },
];

export default function Gallery() {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const items = gridRef.current?.querySelectorAll('.gallery-item');
      if (items) {
        gsap.from(items, {
          y: 40,
          opacity: 0,
          duration: 0.8,
          stagger: 0.08,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: gridRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const openLightbox = useCallback((index: number) => {
    setCurrentIndex(index);
    setLightboxOpen(true);
    document.body.style.overflow = 'hidden';
  }, []);

  const closeLightbox = useCallback(() => {
    setLightboxOpen(false);
    document.body.style.overflow = '';
  }, []);

  const navigate = useCallback((direction: 'prev' | 'next') => {
    setCurrentIndex((prev) => {
      if (direction === 'prev') return prev === 0 ? galleryImages.length - 1 : prev - 1;
      return prev === galleryImages.length - 1 ? 0 : prev + 1;
    });
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!lightboxOpen) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') navigate('prev');
      if (e.key === 'ArrowRight') navigate('next');
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [lightboxOpen, closeLightbox, navigate]);

  return (
    <>
      <section
        id="gallery"
        ref={sectionRef}
        className="relative py-24 md:py-32 bg-siamese-bg"
      >
        <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-siamese-blue mb-4 block">
              Galeri
            </span>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-siamese-text-primary mb-4">
              Anılar
            </h2>
            <p className="text-siamese-text-secondary/60 max-w-xl mx-auto">
              Gece'nin en güzel anları
            </p>
          </div>

          {/* Masonry Grid */}
          <div
            ref={gridRef}
            className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4"
          >
            {galleryImages.map((image, index) => (
              <div
                key={index}
                className="gallery-item break-inside-avoid group relative overflow-hidden rounded-lg cursor-pointer"
                onClick={() => openLightbox(index)}
              >
                <img
                  src={image.src}
                  alt={image.alt}
                  className="w-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-siamese-bg/0 group-hover:bg-siamese-bg/60 transition-all duration-500 flex items-end">
                  <div className="p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                    <p className="text-sm text-siamese-cream font-medium">{image.caption}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Lightbox */}
      {lightboxOpen && (
        <div
          className="fixed inset-0 z-[100] bg-siamese-bg/95 backdrop-blur-xl flex items-center justify-center"
          onClick={closeLightbox}
        >
          <button
            onClick={closeLightbox}
            className="absolute top-6 right-6 p-2 text-siamese-text-secondary hover:text-siamese-cream transition-colors z-10"
            aria-label="Kapat"
          >
            <X size={32} />
          </button>

          <button
            onClick={(e) => { e.stopPropagation(); navigate('prev'); }}
            className="absolute left-4 md:left-8 p-3 text-siamese-text-secondary hover:text-siamese-cream transition-colors z-10"
            aria-label="Önceki"
          >
            <ChevronLeft size={40} />
          </button>

          <button
            onClick={(e) => { e.stopPropagation(); navigate('next'); }}
            className="absolute right-4 md:right-8 p-3 text-siamese-text-secondary hover:text-siamese-cream transition-colors z-10"
            aria-label="Sonraki"
          >
            <ChevronRight size={40} />
          </button>

          <div
            className="max-w-5xl max-h-[85vh] px-4"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={galleryImages[currentIndex].src}
              alt={galleryImages[currentIndex].alt}
              className="max-w-full max-h-[80vh] object-contain rounded-lg"
            />
            <p className="text-center text-siamese-text-secondary mt-4">
              {galleryImages[currentIndex].caption}
            </p>
            <p className="text-center text-siamese-text-secondary/50 text-sm mt-1">
              {currentIndex + 1} / {galleryImages.length}
            </p>
          </div>
        </div>
      )}
    </>
  );
}
