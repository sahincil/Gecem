import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ChevronDown } from 'lucide-react';

export default function Hero() {
  const sectionRef = useRef<HTMLElement>(null);
  const eyebrowRef = useRef<HTMLSpanElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const taglineRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      tl.from(eyebrowRef.current, {
        y: -30,
        opacity: 0,
        duration: 0.8,
        delay: 0.3,
      })
        .from(
          titleRef.current,
          {
            clipPath: 'inset(0 100% 0 0)',
            opacity: 0,
            duration: 1.2,
          },
          '-=0.4'
        )
        .from(
          subtitleRef.current,
          {
            y: 20,
            opacity: 0,
            duration: 0.8,
          },
          '-=0.6'
        )
        .from(
          taglineRef.current,
          {
            y: 20,
            opacity: 0,
            duration: 0.8,
          },
          '-=0.5'
        )
        .from(
          ctaRef.current,
          {
            scale: 0.8,
            opacity: 0,
            duration: 0.6,
          },
          '-=0.4'
        )
        .from(
          imageRef.current,
          {
            scale: 1.1,
            opacity: 0,
            duration: 1.5,
          },
          '-=1.5'
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleScrollToAbout = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.querySelector('#about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="hero"
      ref={sectionRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background Image */}
      <div
        ref={imageRef}
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: 'url(/hero-cat.jpg)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-siamese-bg/70 via-siamese-bg/50 to-siamese-bg" />
        <div className="absolute inset-0 bg-gradient-to-r from-siamese-bg/60 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 sm:px-6 max-w-4xl mx-auto">
        <span
          ref={eyebrowRef}
          className="inline-block text-xs md:text-sm font-semibold uppercase tracking-[0.2em] text-siamese-blue mb-4 md:mb-6"
        >
          Siyam Kedisi
        </span>

        <h1
          ref={titleRef}
          className="font-display text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-bold text-siamese-cream mb-4 md:mb-6 leading-[0.9]"
        >
          Gece'm
        </h1>

        <p
          ref={subtitleRef}
          className="text-sm md:text-base text-siamese-text-secondary/60 tracking-wider mb-4"
        >
          09 Eylül 2018 — 17 Eylül 2024
        </p>

        <p
          ref={taglineRef}
          className="text-base md:text-lg lg:text-xl text-siamese-text-secondary max-w-2xl mx-auto mb-8 md:mb-10 leading-relaxed"
        >
          Bir Siyam kedisi olan Gece'nin hikayesi, fotoğrafları ve kediler hakkında bilgiler.
        </p>

        <a
          ref={ctaRef}
          href="#about"
          onClick={handleScrollToAbout}
          className="inline-flex items-center gap-2 px-8 py-3.5 bg-siamese-blue text-siamese-bg font-semibold rounded-full hover:bg-cyan-300 transition-all duration-300 hover:scale-105 hover:shadow-glow"
        >
          Hikayemi Keşfet
        </a>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce-subtle">
        <a href="#blog" onClick={(e) => { e.preventDefault(); document.querySelector('#blog')?.scrollIntoView({ behavior: 'smooth' }); }}>
          <ChevronDown className="w-6 h-6 text-siamese-text-secondary/40 hover:text-siamese-blue transition-colors" />
        </a>
      </div>
    </section>
  );
}
