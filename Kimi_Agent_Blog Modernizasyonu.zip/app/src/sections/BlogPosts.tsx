import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { ArrowRight, Clock, Calendar } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const posts = [
  {
    id: 1,
    title: 'KEDİLERİ ANLAMAK... KEDİM BENİ SEVİYOR MU?',
    excerpt: 'Biz dahil diğer türler gibi, kedi de içgüdüsel olarak yaşamda kalmak ve soyunu sürdürebilmek ister. Kedilerin sevgi belirtilerini ve davranışlarını anlamak için kapsamlı bir rehber.',
    category: 'Kedi Davranışları',
    date: '30 Haziran 2019',
    readTime: '5 dk',
    image: '/blog-1.jpg',
    featured: true,
  },
  {
    id: 2,
    title: 'Tahılsız Kedi Mamaları Sağlıklı Mı?',
    excerpt: 'Tahıllı Vs. Tahılsız - Kedi beslenmesi üzerine bir yazı. Bugünkü konumuz tahılsız mamaların kediler için gerçekten sağlıklı olup olmadığı.',
    category: 'Beslenme',
    date: '15 Mayıs 2019',
    readTime: '7 dk',
    image: '/blog-2.jpg',
    featured: false,
  },
  {
    id: 3,
    title: 'Kedilerde Ağız ve Diş Sağlığı',
    excerpt: 'Kedilerin diş sağlığı genel sağlıklarının önemli bir göstergesidir. Düzenli bakım ve doğru beslenme ile diş problemlerini önleyebilirsiniz.',
    category: 'Bakım ve Sağlık',
    date: '22 Mart 2019',
    readTime: '4 dk',
    image: '/blog-3.jpg',
    featured: false,
  },
  {
    id: 4,
    title: 'Siyam Kedisi Türleri ve Tarihçe',
    excerpt: 'Siyam kedisi, Tayland kökenli (eski adıyla Siam) dünyanın en eski ve en popüler kedi ırklarından biridir. Tarihçesi ve farklı türleri hakkında bilgiler.',
    category: 'Irk Bilgisi',
    date: '10 Mart 2019',
    readTime: '6 dk',
    image: '/gallery-5.jpg',
    featured: false,
  },
  {
    id: 5,
    title: 'Kuru Mamalar Hakkında Bilinmesi Gerekenler',
    excerpt: 'Kuru mama seçimi yaparken dikkat edilmesi gereken en önemli noktalar. İçerik etiketleri nasıl okunur ve kediler için en uygun besin değerleri nelerdir?',
    category: 'Beslenme',
    date: '5 Mart 2019',
    readTime: '8 dk',
    image: '/blog-2.jpg',
    featured: false,
  },
  {
    id: 6,
    title: 'Bu gün de böyle olsun...',
    excerpt: "Gece'nin günlük yaşamından bir an. Kedilerin basit şeylerden ne kadar keyif aldığını gözlemlemek bize çok şey öğretiyor.",
    category: 'Günlük',
    date: '30 Ekim 2019',
    readTime: '2 dk',
    image: '/gallery-1.jpg',
    featured: false,
  },
];

export default function BlogPosts() {
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = cardsRef.current?.querySelectorAll('.blog-card');
      if (cards) {
        gsap.from(cards, {
          y: 60,
          opacity: 0,
          duration: 0.8,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="blog"
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-siamese-bg-light"
    >
      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-xs font-semibold uppercase tracking-[0.2em] text-siamese-blue mb-4 block">
            Blog
          </span>
          <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-siamese-text-primary mb-4">
            Son Yazılar
          </h2>
          <p className="text-siamese-text-secondary/60 max-w-xl mx-auto">
            Kediler hakkında bakım, sağlık ve yaşam
          </p>
        </div>

        {/* Blog Grid */}
        <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {posts.map((post) => (
            <article
              key={post.id}
              className={`blog-card group bg-siamese-bg rounded-xl overflow-hidden border border-white/5 hover:border-siamese-blue/20 transition-all duration-500 hover:shadow-glow hover:-translate-y-1 ${
                post.featured ? 'md:col-span-2 lg:col-span-2' : ''
              }`}
            >
              <div className={`relative overflow-hidden ${post.featured ? 'aspect-[16/9]' : 'aspect-[16/10]'}`}>
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-siamese-bg/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
                <span className="absolute top-4 left-4 px-3 py-1 text-xs font-semibold bg-siamese-blue/15 text-siamese-blue rounded-full backdrop-blur-sm">
                  {post.category}
                </span>
              </div>

              <div className="p-6">
                <div className="flex items-center gap-3 text-xs text-siamese-text-secondary/50 mb-3">
                  <span className="flex items-center gap-1">
                    <Calendar size={12} />
                    {post.date}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {post.readTime}
                  </span>
                </div>

                <h3 className={`font-display font-semibold text-siamese-text-primary mb-3 group-hover:text-siamese-blue transition-colors ${
                  post.featured ? 'text-2xl md:text-3xl' : 'text-lg'
                }`}>
                  {post.title}
                </h3>

                <p className={`text-siamese-text-secondary/70 mb-4 ${
                  post.featured ? 'text-base line-clamp-3' : 'text-sm line-clamp-2'
                }`}>
                  {post.excerpt}
                </p>

                <div className="flex items-center gap-2 text-siamese-blue font-medium text-sm group/link">
                  <span className="group-hover/link:underline">Devamını Oku</span>
                  <ArrowRight size={14} className="transition-transform group-hover/link:translate-x-1" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
