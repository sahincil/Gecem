import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Play } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  const sectionRef = useRef<HTMLElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from(imageRef.current, {
        x: -60,
        opacity: 0,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });

      gsap.from(contentRef.current, {
        x: 60,
        opacity: 0,
        duration: 1,
        delay: 0.2,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 70%',
          toggleActions: 'play none none reverse',
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleScrollToVideos = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.querySelector('#videos')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-siamese-bg-light"
    >
      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center max-w-6xl mx-auto">
          {/* Image */}
          <div ref={imageRef} className="relative">
            <div className="absolute -left-4 top-8 bottom-8 w-1 bg-siamese-blue rounded-full" />
            <div className="relative overflow-hidden rounded-2xl shadow-2xl shadow-black/30">
              <img
                src="/about-cat.jpg"
                alt="Gece portre"
                className="w-full aspect-[3/4] object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-siamese-bg/40 to-transparent" />
            </div>
          </div>

          {/* Content */}
          <div ref={contentRef}>
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-siamese-blue mb-4 block">
              Hakkımda
            </span>
            <h2 className="font-display text-4xl md:text-5xl text-siamese-text-primary mb-6">
              Ben Kimim?
            </h2>

            <div className="space-y-4 text-siamese-text-secondary leading-relaxed">
              <p>
                09 Eylül 2018 tarihinde doğan, klasik tip ve renkte dişi Siyam kedisiyim.
                Balıkesir ili, Edremit ilçesinde ailemle birlikte yaşıyorum. Sizleri
                bilgilendirmek adına ailem, adıma bu bloğu oluşturdu.
              </p>
              <p>
                Umarım sahiplendiğiniz veya sahipleneceğiniz kardeşlerime daha iyi
                bakmanız için faydalı olabilirim. Hoşçakalın.
              </p>
            </div>

            <blockquote className="mt-8 pl-5 border-l-[3px] border-siamese-blue">
              <p className="text-siamese-text-secondary/60 italic">
                17 Eylül 2024 tarihinde emboli sebebiyle melek olmuştur.
              </p>
            </blockquote>

            <p className="mt-6 text-sm text-siamese-text-secondary/40">
              Bu bloğun hazırlanmasında{' '}
              <a
                href="http://www.siyamkedi.com/"
                target="_blank"
                rel="noopener noreferrer"
                className="text-siamese-blue hover:underline"
              >
                www.siyamkedi.com
              </a>{' '}
              sitesinden faydalanılmıştır.
            </p>

            <a
              href="#videos"
              onClick={handleScrollToVideos}
              className="inline-flex items-center gap-2 mt-8 px-6 py-3 border-2 border-siamese-blue text-siamese-blue rounded-full hover:bg-siamese-blue hover:text-siamese-bg transition-all duration-300 font-medium"
            >
              <Play size={16} />
              Videolarımı İzle
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
