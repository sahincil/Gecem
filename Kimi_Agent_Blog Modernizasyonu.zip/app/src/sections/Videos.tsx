import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Play, X } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const videos = [
  {
    id: 1,
    title: "Gece'nin İlk Adımları",
    thumbnail: '/video-1.jpg',
    duration: '2:34',
    youtubeId: 'dQw4w9WgXcQ',
  },
  {
    id: 2,
    title: 'Oyun Zamanı',
    thumbnail: '/video-2.jpg',
    duration: '1:45',
    youtubeId: 'dQw4w9WgXcQ',
  },
  {
    id: 3,
    title: 'Siyam Kedisi Davranışları',
    thumbnail: '/video-3.jpg',
    duration: '4:12',
    youtubeId: 'dQw4w9WgXcQ',
  },
  {
    id: 4,
    title: 'Gece ve Kardeşleri',
    thumbnail: '/gallery-8.jpg',
    duration: '3:08',
    youtubeId: 'dQw4w9WgXcQ',
  },
];

export default function Videos() {
  const [activeVideo, setActiveVideo] = useState<string | null>(null);
  const sectionRef = useRef<HTMLElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const cards = cardsRef.current?.querySelectorAll('.video-card');
      if (cards) {
        gsap.from(cards, {
          scale: 0.9,
          opacity: 0,
          duration: 0.8,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: cardsRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const openVideo = (youtubeId: string) => {
    setActiveVideo(youtubeId);
    document.body.style.overflow = 'hidden';
  };

  const closeVideo = () => {
    setActiveVideo(null);
    document.body.style.overflow = '';
  };

  return (
    <>
      <section
        id="videos"
        ref={sectionRef}
        className="relative py-24 md:py-32 bg-siamese-bg"
      >
        <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
          {/* Section Header */}
          <div className="text-center mb-16">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-siamese-blue mb-4 block">
              Videolar
            </span>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-siamese-text-primary mb-4">
              Gece'nin Anları
            </h2>
          </div>

          {/* Video Grid */}
          <div ref={cardsRef} className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-5xl mx-auto">
            {videos.map((video) => (
              <div
                key={video.id}
                className="video-card group cursor-pointer"
                onClick={() => openVideo(video.youtubeId)}
              >
                <div className="relative aspect-video rounded-xl overflow-hidden">
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-siamese-bg/30 group-hover:bg-siamese-bg/50 transition-all duration-500" />

                  {/* Play Button */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-siamese-bg/70 backdrop-blur-sm flex items-center justify-center border border-white/10 group-hover:scale-110 transition-transform duration-500">
                      <Play size={28} className="text-siamese-blue ml-1" fill="currentColor" />
                    </div>
                  </div>

                  {/* Duration Badge */}
                  <div className="absolute bottom-3 right-3 px-2 py-1 bg-siamese-bg/80 rounded text-xs text-siamese-text-secondary font-medium">
                    {video.duration}
                  </div>
                </div>

                <h3 className="mt-4 font-display text-lg md:text-xl text-siamese-text-primary group-hover:text-siamese-blue transition-colors">
                  {video.title}
                </h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Video Modal */}
      {activeVideo && (
        <div
          className="fixed inset-0 z-[100] bg-siamese-bg/95 backdrop-blur-xl flex items-center justify-center p-4"
          onClick={closeVideo}
        >
          <button
            onClick={closeVideo}
            className="absolute top-6 right-6 p-2 text-siamese-text-secondary hover:text-siamese-cream transition-colors z-10"
            aria-label="Kapat"
          >
            <X size={32} />
          </button>

          <div
            className="w-full max-w-4xl aspect-video"
            onClick={(e) => e.stopPropagation()}
          >
            <iframe
              src={`https://www.youtube.com/embed/${activeVideo}?autoplay=1`}
              title="YouTube video player"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
              className="w-full h-full rounded-xl"
            />
          </div>
        </div>
      )}
    </>
  );
}
