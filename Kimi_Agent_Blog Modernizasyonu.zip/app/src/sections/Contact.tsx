import { useState, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Send, CheckCircle, Mail, User, MessageSquare, Tag } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

export default function Contact() {
  const [formState, setFormState] = useState<'idle' | 'submitting' | 'success'>('idle');
  const sectionRef = useRef<HTMLElement>(null);
  const formRef = useRef<HTMLFormElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const fields = formRef.current?.querySelectorAll('.form-field');
      if (fields) {
        gsap.from(fields, {
          y: 30,
          opacity: 0,
          duration: 0.6,
          stagger: 0.1,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: formRef.current,
            start: 'top 80%',
            toggleActions: 'play none none reverse',
          },
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormState('submitting');
    setTimeout(() => {
      setFormState('success');
    }, 1500);
  };

  return (
    <section
      id="contact"
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-siamese-bg-light"
    >
      <div className="container-wide mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-siamese-blue mb-4 block">
              İletişim
            </span>
            <h2 className="font-display text-4xl md:text-5xl text-siamese-text-primary mb-4">
              Bana Ulaşın
            </h2>
            <p className="text-siamese-text-secondary/60">
              Kediler hakkında sorularınız veya paylaşmak istedikleriniz için iletişime geçebilirsiniz.
            </p>
          </div>

          {formState === 'success' ? (
            <div className="text-center py-12">
              <CheckCircle size={64} className="mx-auto text-siamese-blue mb-4" />
              <h3 className="font-display text-2xl text-siamese-text-primary mb-2">
                Mesajınız İletildi!
              </h3>
              <p className="text-siamese-text-secondary/60">
                En kısa sürede size dönüş yapacağız.
              </p>
            </div>
          ) : (
            <form ref={formRef} onSubmit={handleSubmit} className="space-y-6">
              <div className="form-field relative">
                <User size={18} className="absolute left-0 top-3.5 text-siamese-text-secondary/30" />
                <input
                  type="text"
                  placeholder="İsim"
                  required
                  className="w-full bg-transparent border-b border-white/10 focus:border-siamese-blue py-3 pl-8 text-siamese-text-primary placeholder:text-siamese-text-secondary/30 outline-none transition-colors"
                />
              </div>

              <div className="form-field relative">
                <Mail size={18} className="absolute left-0 top-3.5 text-siamese-text-secondary/30" />
                <input
                  type="email"
                  placeholder="E-posta"
                  required
                  className="w-full bg-transparent border-b border-white/10 focus:border-siamese-blue py-3 pl-8 text-siamese-text-primary placeholder:text-siamese-text-secondary/30 outline-none transition-colors"
                />
              </div>

              <div className="form-field relative">
                <Tag size={18} className="absolute left-0 top-3.5 text-siamese-text-secondary/30" />
                <input
                  type="text"
                  placeholder="Konu"
                  required
                  className="w-full bg-transparent border-b border-white/10 focus:border-siamese-blue py-3 pl-8 text-siamese-text-primary placeholder:text-siamese-text-secondary/30 outline-none transition-colors"
                />
              </div>

              <div className="form-field relative">
                <MessageSquare size={18} className="absolute left-0 top-3.5 text-siamese-text-secondary/30" />
                <textarea
                  placeholder="Mesaj"
                  rows={5}
                  required
                  className="w-full bg-transparent border-b border-white/10 focus:border-siamese-blue py-3 pl-8 text-siamese-text-primary placeholder:text-siamese-text-secondary/30 outline-none transition-colors resize-none"
                />
              </div>

              <button
                type="submit"
                disabled={formState === 'submitting'}
                className="form-field w-full py-4 bg-siamese-blue text-siamese-bg font-semibold rounded-full hover:bg-cyan-300 transition-all duration-300 flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {formState === 'submitting' ? (
                  <span className="animate-pulse">Gönderiliyor...</span>
                ) : (
                  <>
                    <Send size={18} />
                    Gönder
                  </>
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </section>
  );
}
